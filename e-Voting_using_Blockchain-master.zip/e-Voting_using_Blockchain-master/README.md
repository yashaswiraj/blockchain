# e-Voting_using_Blockchain

e-Voting_using_Blockchain

C++ source

Implementation (small model) for our ideo on e-Voting using Blockchain technology.
